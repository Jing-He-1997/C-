﻿using System;

namespace _016_布尔运算
{
    class Program
    {
        static void Main(string[] args)
        {
            int score = 99;
            bool res = score >= 50;

            Console.WriteLine(res);
            Console.ReadKey();

        }
    }
}
