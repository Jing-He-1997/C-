﻿using System;

namespace _002_变量
{
    class Program
    {
        static void Main(string[] args)
        {
            int age = 20;
            int hp = 60;
            string name = "Siki";
            Console.WriteLine(age);
            Console.WriteLine(hp);
            Console.WriteLine(name);
            Console.ReadKey();
        }
    }
}
