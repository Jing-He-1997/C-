﻿using System;

namespace _026_for循环
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int index = 1; index <= 9; index++)
            {
                Console.WriteLine(index);
            }
            Console.ReadKey();


            //for(; ; )//初始化条件和循环判断条件都不写 就是死循环
            //{

            //}
        }
    }
}
